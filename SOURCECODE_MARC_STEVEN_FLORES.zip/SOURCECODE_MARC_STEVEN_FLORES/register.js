function save(){ 
    console.log("Save called");
    let users = localStorage.getItem("users");
    users = JSON.parse(users);
    if(users == null) {
        users =[];

    }

    var user=JSON.stringify({
        name:document.getElementById("name").value,
        email:document.getElementById("email").value,
        contact:document.getElementById("contact").value,
        Age:document.getElementById("Age").value,
        Course:document.getElementById("Course").value,
        
        comment:document.getElementById("comment").value,

    })
    users.push(user);
    localStorage.setItem("users",JSON.stringify(users));

}