let users=localStorage.getItem("users");
users=JSON.parse(users)
if(users==null){
    users=[];
}

users_data='<table style ="border:1px solid";>'
for( user in users){
    let registrant=JSON.parse(users[user]);
    users_data+="<tr>";
    users_data+="<td >"+registrant["name"]+"</td>"+
    "<td>"+registrant["email"]+"</td>"+
    "<td>"+registrant["contact"]+"</td>"+
    "<td>"+registrant["Age"]+"</td>"+
    "<td>"+registrant["Course"]+"</td>"+
    "<td>"+registrant["comment"]+"</td>"+
    "</tr>"
}
users_data+="</table>";
document.getElementById("data").innerHTML=users_data;

//this is button
var read_localstorage=document.getElementById("read_localstorage")
var delete_data=document.getElementById("delete_data")
var read_all_data=document.getAnimations("read_all_data")


delete_data.onclick=function(){
    localStorage.clear('users')

}
read_all_data.onclick=function(){
    var keys =Object.keys(localStorage);
    console.log(keys);
    
    for(var keys of keys){
        console.log("key:"+key+":Value :"+localStorage.getItem(key));
    }

}